-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 19, 2024 at 03:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fullname` varchar(259) DEFAULT NULL,
  `mobilenumber` bigint(11) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fullname`, `mobilenumber`, `email`, `username`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'Darshan SM', 8546833561, 'darshananu452@gmail.com', 'admin', '008b7a6ca1b0ee7a32b6792b6832a9e4', '2023-09-12 05:16:16', '18-10-2016 04:18:16');

-- --------------------------------------------------------

--
-- Table structure for table `complaintremark`
--

CREATE TABLE `complaintremark` (
  `id` int(11) NOT NULL,
  `complaintNumber` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `remark` mediumtext DEFAULT NULL,
  `remarkDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `complaintremark`
--

INSERT INTO `complaintremark` (`id`, `complaintNumber`, `status`, `remark`, `remarkDate`) VALUES
(5, 10, 'closed', 'dont we are here', '2024-03-01 06:22:42'),
(6, 11, 'in process', 'ok we look in it', '2024-03-01 07:36:55'),
(7, 11, 'in process', 'rehethehtehe', '2024-03-01 07:37:07'),
(8, 13, 'in process', 'dont woory ananya i will take care of him', '2024-03-01 08:14:40');

-- --------------------------------------------------------

--
-- Table structure for table `dept`
--

CREATE TABLE `dept` (
  `id` int(11) NOT NULL,
  `deptName` varchar(255) DEFAULT NULL,
  `deptDescription` longtext DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `dept`
--

INSERT INTO `dept` (`id`, `deptName`, `deptDescription`, `creationDate`, `updationDate`) VALUES
(10, 'Computer Science & Engineering ', 'A computer engineer fuses electrical engineering and computer science to develop new technology', '2024-02-09 14:48:13', '2024-03-11 06:31:33'),
(11, 'Computer Science & Engineering ( Artificial Intelligence )', 'Computer Science and Engineering (Artificial Intelligence), is a new branch which consists of Artificial Intelligence is a broad multidisciplinary area drawing from computer science.', '2024-02-09 14:49:34', NULL),
(12, 'Computer Science & Engineering ( Data Science )', 'Overview. Program Description. B. Tech in Computer Science & Engineering(Data Science) is a journey towards mastering CSE in the field of Data Science applying Machine Learning techniques.', '2024-02-09 14:50:38', NULL),
(13, 'Computer science & Business System ', 'Computer science and business system students will learn about basic engineering techniques like basic subjects: digital electronics, Python, Java, computer networks, database management systems.', '2024-02-09 14:51:30', NULL),
(14, 'Electronics & Communication  Engineering', 'Electronics and communication engineering (ECE) is a discipline of engineering that involves developing and testing electronic circuits and communication devices like transmitters, receivers and integrated circuits.', '2024-02-09 14:52:09', NULL),
(15, 'Information Science & Engineering', 'It is an area of professional practice that addresses the effective communication between information in the context of social, organizational, and individual needs in order to build the software or embedded applications for societal benefit.', '2024-02-09 14:52:55', NULL),
(16, 'Mechanical Engineering ', 'It is an engineering branch that combines engineering physics and mathematics principles with materials science, to design, analyze, manufacture, and maintain mechanical systems.', '2024-02-09 14:53:44', NULL),
(17, 'Civil Engineering', 'Civil engineering is a professional engineering discipline that deals with the design, construction, and maintenance of the physical and naturally built environment.', '2024-02-09 14:54:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stutyp`
--

CREATE TABLE `stutyp` (
  `id` int(11) NOT NULL,
  `stutypName` varchar(255) DEFAULT NULL,
  `stutypDescription` tinytext DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `stutyp`
--

INSERT INTO `stutyp` (`id`, `stutypName`, `stutypDescription`, `postingDate`, `updationDate`) VALUES
(10, 'Hostal ', 'Who Stays in Hostal', '2024-02-09 15:30:05', NULL),
(11, 'Day Scholar', 'Who not stays in hostal', '2024-02-09 15:30:32', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subdept`
--

CREATE TABLE `subdept` (
  `id` int(11) NOT NULL,
  `deptid` int(11) DEFAULT NULL,
  `subdept` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `subdept`
--

INSERT INTO `subdept` (`id`, `deptid`, `subdept`, `creationDate`, `updationDate`) VALUES
(12, 15, 'Basic Science', '2024-03-01 07:05:12', NULL),
(13, 10, 'Business management', '2024-03-01 07:45:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `submit`
--

CREATE TABLE `submit` (
  `id` int(11) NOT NULL,
  `complaint_id` int(11) NOT NULL,
  `action` varchar(20) NOT NULL,
  `submitdate` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `submit`
--

INSERT INTO `submit` (`id`, `complaint_id`, `action`, `submitdate`) VALUES
(1, 15, 'inserted', '2024-03-18 22:12:29'),
(2, 16, 'inserted', '2024-03-18 22:12:55');

-- --------------------------------------------------------

--
-- Table structure for table `tblcomplaints`
--

CREATE TABLE `tblcomplaints` (
  `complaintNumber` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `dept` int(11) DEFAULT NULL,
  `subdept` varchar(255) DEFAULT NULL,
  `complaintType` varchar(255) DEFAULT NULL,
  `stutyp` varchar(255) DEFAULT NULL,
  `noc` varchar(255) DEFAULT NULL,
  `complaintDetails` mediumtext DEFAULT NULL,
  `complaintFile` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT NULL,
  `lastUpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcomplaints`
--

INSERT INTO `tblcomplaints` (`complaintNumber`, `userId`, `dept`, `subdept`, `complaintType`, `stutyp`, `noc`, `complaintDetails`, `complaintFile`, `regDate`, `status`, `lastUpdationDate`) VALUES
(10, 7, 10, 'BUsness managemenst', 'General complaints', 'Day Scholar', 'vailation', 'jajshwsgd', 'a96697453b9cf52c80be9acfba82aff9.png', '2024-03-01 06:21:56', 'closed', '2024-03-01 06:22:42'),
(11, 7, 15, 'Basic Science', 'General complaints', 'Hostal ', 'vailation', 'darshan is happy', '873b18312eac0e2c92518fb3dbb4dde9.png', '2024-03-01 07:05:50', 'in process', '2024-03-01 07:36:55'),
(12, 7, 15, 'Basic Science', 'Sexual misconduct', 'Day Scholar', 'vailation', 'asadadd', '07b648e9cbe38aa8c6a48a37563bac59.png', '2024-03-01 07:36:22', NULL, NULL),
(13, 10, 14, 'Select Subdept', 'General complaints', 'Day Scholar', 'Kirukula', 'Darshan S M student of IS change of branch from ece comes to our class and gives kirukula everyday. Even shivu is fed up. ', 'e699eb6f1ecb1a7306dee69a78182ccb.jpg', '2024-03-01 08:11:49', 'in process', '2024-03-01 08:14:40'),
(14, 7, 10, 'Business management', 'Behavioral concerns', 'Day Scholar', 'vailation', 'plz work agu', 'a1a1fbdc404eceeee77ce3234bc5d11d.png', '2024-03-11 06:31:33', NULL, NULL),
(15, 12, 15, 'Basic Science', 'Sexual misconduct', 'Day Scholar', 'vailation', 'hdhdhgdca', '5d63c781b77f847d33999a253c9dac91.png', '2024-03-18 16:42:29', NULL, NULL),
(16, 12, 15, 'Basic Science', 'Discrimination', 'Day Scholar', 'Kirukula', 'jcsjahvcjhc', '82c554056484a861a478b158db965dbb.png', '2024-03-18 16:42:55', NULL, NULL);

--
-- Triggers `tblcomplaints`
--
DELIMITER $$
CREATE TRIGGER `check_complaint_limit` BEFORE INSERT ON `tblcomplaints` FOR EACH ROW BEGIN
    DECLARE v_complaint_count INT;
    -- Count the number of complaints lodged by the user
    SELECT COUNT(*) INTO v_complaint_count
    FROM tblcomplaints
    WHERE userId = NEW.userId;

    -- If the count exceeds 2, raise an exception
    IF v_complaint_count >= 2 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot lodge more than 2 complaints per student.';
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `insert_into_submit` AFTER INSERT ON `tblcomplaints` FOR EACH ROW BEGIN
    INSERT INTO submit (complaint_id, action, submitdate)
    VALUES (NEW.complaintNumber, 'inserted', NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `usn` varchar(10) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `contactNo` bigint(11) DEFAULT NULL,
  `address` tinytext DEFAULT NULL,
  `Stutyp` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `pincode` int(6) DEFAULT NULL,
  `userImage` varchar(255) DEFAULT NULL,
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `usn`, `password`, `contactNo`, `address`, `Stutyp`, `country`, `pincode`, `userImage`, `regDate`, `updationDate`, `status`) VALUES
(7, 'Darshan SM', '4mh21is118', 'b80219a145ddbe68e471b3b943b3bf19', 8546833561, '#1, Ashrama Road Hinkal Mysore', 'Day Scholar', 'india', 570030, '24dcf901dba441cd4e9ba64bccfcf6a8.png', '2024-02-08 14:16:48', NULL, 1),
(10, 'Ananya D', '4MH21EC004', '0283ca058220e0f0d2ff6281c6ff7d71', 1236547891, NULL, NULL, NULL, NULL, NULL, '2024-03-01 08:07:54', NULL, 1),
(11, 'tharun', '4mh21is107', 'edeb493746a354448e52b13ea217ac50', 7022039451, NULL, NULL, NULL, NULL, NULL, '2024-03-11 07:46:10', NULL, 1),
(12, 'sinchan', '4MH21IS091', '017f6e25d355d7c896d12c02bd03bc16', 9980265073, NULL, NULL, NULL, NULL, NULL, '2024-03-18 16:41:36', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaintremark`
--
ALTER TABLE `complaintremark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dept`
--
ALTER TABLE `dept`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stutyp`
--
ALTER TABLE `stutyp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subdept`
--
ALTER TABLE `subdept`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submit`
--
ALTER TABLE `submit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcomplaints`
--
ALTER TABLE `tblcomplaints`
  ADD PRIMARY KEY (`complaintNumber`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `complaintremark`
--
ALTER TABLE `complaintremark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `dept`
--
ALTER TABLE `dept`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `stutyp`
--
ALTER TABLE `stutyp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `subdept`
--
ALTER TABLE `subdept`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `submit`
--
ALTER TABLE `submit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblcomplaints`
--
ALTER TABLE `tblcomplaints`
  MODIFY `complaintNumber` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
