	<div class="footer">
		<div class="container">
			 

			<b class="copyright">&copy; 2024 SGS </b> All rights reserved.
		</div>
	</div>